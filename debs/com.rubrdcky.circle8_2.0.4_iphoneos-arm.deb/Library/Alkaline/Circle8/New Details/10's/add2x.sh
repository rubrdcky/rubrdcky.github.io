#!/bin/bash
for f in *@3x.png
do
NEW=${f%@3x.png}@2x.png
cp ${f} "${NEW}"
done
