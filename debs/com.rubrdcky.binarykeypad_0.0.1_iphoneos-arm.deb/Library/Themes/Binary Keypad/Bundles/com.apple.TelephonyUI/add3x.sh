#!/bin/bash
for f in *@2x~iphone.png
do
NEW=${f%@2x~iphone.png}@3x~iphone.png
cp ${f} "${NEW}"
done
