#import <Preferences/PSListController.h>

@interface NBLRootListController : PSListController

@end
